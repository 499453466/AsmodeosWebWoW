<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['php_info'] = "Información PHP";
$l['browser_no_iframe_support'] = "Tu navegador no soporta iFrames.";

