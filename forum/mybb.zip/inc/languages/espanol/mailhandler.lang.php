<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */
 
$l['error_no_connection'] = 'Se ha producido un error al establecer una conexión con el servidor: ';
$l['error_no_message'] = 'No se ha especificado un mensaje.';
$l['error_no_subject'] = 'No se ha especificado un título.';
$l['error_no_recipient'] = 'No se ha especificado el destinatario.';
$l['error_not_sent'] = 'Se ha producido un error al intentar enviar un email a través de la función de PHP mail.';
$l['error_status_missmatch'] = 'El estado del servidor ha devuelto el siguiente resultado: ';
$l['error_data_not_sent'] = 'Esta información no se ha podido enviar al servidor: ';

$l['error_occurred'] = 'Se han producido uno o más errores. Por favor, corríje los siguientes errores antes de continuar.<br />';
