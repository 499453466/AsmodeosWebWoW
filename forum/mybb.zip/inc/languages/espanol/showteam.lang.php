<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['nav_showteam'] = "El equipo del foro";
$l['forum_team'] = "Equipo del foro";
$l['moderators'] = "Moderadores";
$l['username'] = "Nombre de usuario";
$l['lastvisit'] = "Última visita";
$l['email'] = "Email";
$l['pm'] = "MP";
$l['mod_forums'] = "Foro(s)";
$l['online'] = "En línea";
$l['offline'] = "Desconectado";
$l['away'] = "Ausente";

$l['group_leaders'] = "Líder(es)";
$l['group_members'] = "Miembro(s)";

$l['no_members'] = "No hay miembros en este grupo";

$l['error_noteamstoshow'] = "No hay equipo del foro para mostrar.";
