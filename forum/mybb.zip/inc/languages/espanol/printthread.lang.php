<?php 
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['forum'] = "Foro:";
$l['printable_version'] = "Versión para impresión";
$l['pages'] = "Páginas:";
$l['thread'] = "Tema:";
