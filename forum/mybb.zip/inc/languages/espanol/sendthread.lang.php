<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['nav_sendthread'] = "Enviar tema a un amigo";

$l['send_thread'] = "Enviar a un amigo";
$l['recipient'] = "Destinatario:";
$l['recipient_note'] = "Escribe la dirección de email de tu amigo.";
$l['subject'] = "Asunto:";
$l['message'] = "Mensaje:";
$l['error_nosubject'] = "Debes introducir un asunto para el mensaje para enviar el tema";
$l['error_nomessage'] = "Debes introducir un mensaje antes de enviar el tema a tu amigo";

